from django.urls import path
from . import views

urlpatterns = [
    path('', views.dashboard, name='dashboard'),
    path('api/schedule/', views.schedule_job, name='schedule_job'),
    path('api/forecast/', views.forecast_data, name='forecast_data'),
]
