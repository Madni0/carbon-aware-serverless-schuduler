from django.shortcuts import render
from django.http import JsonResponse
from backend.decision_engine import DecisionEngine
import json

# Initialize the decision engine
engine = DecisionEngine()

def dashboard(request):
    """Main dashboard view with provider selection."""
    provider = request.GET.get('provider', 'AWS')
    multi_region = engine.get_multi_region_status(provider)
    context = {
        'title': 'Carbon-Aware RL Scheduler',
        'multi_region': multi_region,
        'current_provider': provider,
        'providers': ['AWS', 'Azure', 'GCP']
    }
    return render(request, 'dashboard.html', context)

def schedule_job(request):
    """API endpoint to schedule a job and get a decision."""
    if request.method == 'POST':
        try:
            data = json.loads(request.body)
            job_details = data.get('job', {'id': 'job-123', 'compute': 'high'})
            decision = engine.decide_scheduling(job_details)
            return JsonResponse(decision)
        except Exception as e:
            return JsonResponse({'error': str(e)}, status=400)
    
    # For GET, just return a sample decision for UI testing
    decision = engine.decide_scheduling({'id': 'sample-job'})
    return JsonResponse(decision)

def forecast_data(request):
    """API endpoint to get carbon forecast data."""
    forecasts = engine.forecaster.get_forecast(horizon=24)
    return JsonResponse({'forecasts': forecasts})
