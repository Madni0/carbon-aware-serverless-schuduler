from .api_bridge import ForecastingModel, SchedulerModel
import numpy as np
import pandas as pd
import os
from django.conf import settings

class DecisionEngine:
    def __init__(self):
        # Update this URL with the one from Ngrok/Colab
        self.colab_url = getattr(settings, 'COLAB_API_URL', None)
        
        self.forecaster = ForecastingModel(api_url=self.colab_url)
        self.scheduler = SchedulerModel(api_url=self.colab_url)
        self.data_path = os.path.join(settings.BASE_DIR, 'data/uk_carbon_raw.csv')

    def update_real_time_data(self):
        """Simulates fetching new data from the grid and updating the CSV."""
        try:
            df = pd.read_csv(self.data_path)
            last_val = df['carbon_intensity'].iloc[-1]
            # Simulate a small random walk for carbon intensity
            new_val = last_val + np.random.normal(0, 5)
            new_val = max(50, min(400, new_val)) # Keep it in realistic range
            
            new_row = pd.DataFrame({
                'timestamp': [pd.Timestamp.now()],
                'carbon_intensity': [new_val]
            })
            
            # Append to CSV
            new_row.to_csv(self.data_path, mode='a', header=False, index=False)
            return new_val
        except Exception as e:
            print(f"Error updating CSV: {e}")
            return 150.0
        
    def decide_scheduling(self, job_details=None):
        # Update CSV with "Live" data first
        self.update_real_time_data()
        
        # Get current carbon from local CSV
        try:
            df = pd.read_csv(self.data_path)
            current_carbon = float(df['carbon_intensity'].iloc[-1])
        except:
            current_carbon = 150.0
        
        # Get forecast from Colab API
        forecast_result = self.forecaster.get_forecast(horizon=12)
        if forecast_result and len(forecast_result) > 0:
            next_forecast = forecast_result[0].get('forecast_carbon_intensity', 150.0)
        else:
            next_forecast = 150.0
            forecast_result = [{"timestamp": i, "forecast_carbon_intensity": 150.0} for i in range(12)]
        
        # Construct state for RL (Must be 9 elements to match Colab model)
        # [Carbon_A, Carbon_B, Carbon_C, Lat_A, Lat_B, Lat_C, Deadline, Priority, Forecast]
        carbon_a = current_carbon
        carbon_b = current_carbon + 20 # Simulated shift like in Colab
        carbon_c = 250.0 # Static US region like in Colab
        
        latency = np.array([55, 75, 25])
        deadline = job_details.get('deadline', 5.0) if job_details else 5.0
        priority = job_details.get('priority', 0.0) if job_details else 0.0
        
        state = np.array([
            carbon_a, carbon_b, carbon_c, 
            latency[0], latency[1], latency[2], 
            deadline, priority, next_forecast
        ], dtype=np.float32)
        
        # Get action from Colab API
        action_idx = self.scheduler.predict(state)
        
        actions = ["REGION_A (UK)", "REGION_B (EU)", "REGION_C (US)", "DELAY"]
        decision = actions[action_idx]
        
        reason = f"Colab AI predicts {next_forecast:.1f} gCO2. RL Agent selects: {decision}."
        if not self.colab_url:
            reason = "[SIMULATION] " + reason
            
        return {
            'action': decision,
            'reason': reason,
            'carbon_estimate': current_carbon,
            'forecast': forecast_result,
            'state': state.tolist()
        }

    def get_multi_region_status(self, provider='AWS'):
        try:
            df = pd.read_csv(self.data_path)
            current = float(df['carbon_intensity'].iloc[-1])
        except:
            current = 150.0
            
        providers = {
            'AWS': {'US East': f"{current*1.2:.1f}", 'EU Ireland': f"{current:.1f}", 'Tokyo': "450.0"},
            'Azure': {'East US': f"{current*1.1:.1f}", 'West Europe': f"{current*0.9:.1f}", 'SE Asia': "500.0"},
            'GCP': {'us-central1': f"{current*1.3:.1f}", 'europe-west1': f"{current*0.8:.1f}", 'asia-east1': "420.0"}
        }
        return providers.get(provider, providers['AWS'])
