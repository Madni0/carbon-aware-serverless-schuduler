import requests
import os

class ForecastingModel:
    def __init__(self, api_url=None):
        self.api_url = api_url

    def get_forecast(self, horizon=24):
        """Calls the remote Colab API for forecasts."""
        if not self.api_url:
            return [{"timestamp": i, "forecast_carbon_intensity": 150.0} for i in range(horizon)]
        
        try:
            response = requests.get(f"{self.api_url}/forecast?horizon={horizon}", timeout=5)
            if response.status_code == 200:
                return response.json()['forecast']
        except:
            pass
        
        # Fallback if API is down
        return [{"timestamp": i, "forecast_carbon_intensity": 150.0} for i in range(horizon)]

class SchedulerModel:
    def __init__(self, api_url=None):
        self.api_url = api_url

    def predict(self, state):
        """Calls the remote Colab API for RL decision."""
        if not self.api_url:
            return 3 # Default to delay
        
        try:
            response = requests.post(f"{self.api_url}/predict", json={'state': state.tolist()}, timeout=5)
            if response.status_code == 200:
                return int(response.json()['action'])
        except:
            pass
        
        return 3 # Fallback to delay
