# 🌿 CarbonFlow AI: Predictive Carbon-Aware RL Scheduler
### Master Thesis Project Report

## 1. Project Overview
**CarbonFlow AI** is an intelligent scheduling platform designed to reduce the carbon footprint of cloud computing workloads. By integrating **Deep Learning (LSTM)** for carbon forecasting and **Reinforcement Learning (DQN)** for decision-making, the system automatically determines the most "green" time and region to execute computational tasks.

## 2. Core Problem
Cloud data centers contribute significantly to global CO2 emissions. Carbon intensity varies by **Time** (renewables like wind/solar fluctuate) and **Location** (different regional grids have different energy mixes). Static scheduling fails to exploit these fluctuations.

## 3. Advanced Features
### 🚀 Colab-to-Local Bridge (Cloud AI)
To keep the local environment lightweight and "clean," the heavy AI engines (TensorFlow and Stable-Baselines3) are hosted in **Google Colab**. A secure **Ngrok tunnel** creates a bridge, allowing the local Django dashboard to fetch sub-second predictions from the cloud-based brain.

### 🔄 Dynamic "Real-World" Data Ingestion
The system is no longer static. Every time a job is submitted, the **Decision Engine** simulates a live grid feed by generating a new carbon data point and appending it to `uk_carbon_raw.csv`. This ensures the model is always reacting to a "living" environment.

### 🧠 9-Feature State Analysis
The RL Agent performs a deep analysis of the environment using a 9-element state vector:
*   **Regional Carbon**: Real-time intensity for UK, EU, and US regions.
*   **Network Latency**: Current ping/delay for all three target regions.
*   **Workload Context**: Job deadline, priority, and the LSTM's 24-hour predictive forecast.

## 4. Technical Architecture

### A. LSTM Forecasting Engine (The "Eyes")
*   **Purpose**: Predicts the carbon intensity of the power grid for the next 24 hours.
*   **Mechanism**: A Long Short-Term Memory (LSTM) neural network trained on historical UK Grid data.

### B. DQN Reinforcement Learning (The "Brain")
*   **Purpose**: Makes the final scheduling decision (UK, EU, US, or DELAY).
*   **Reward Function**: Penalizes carbon emissions and latency violations, finding the "Goldilocks" zone of performance vs. sustainability.

### C. Premium Dashboard (The "Command Center")
*   **Visuals**: High-fidelity Glassmorphism UI with real-time Chart.js projections.
*   **Activity Trace**: A live "AI Thinking" log that shows every handshake and decision.
*   **Metrics**: Real-time tracking of **Carbon Savings**, **Model Confidence**, and **Optimized Job Counts**.

## 5. Technical Stack
*   **Backend**: Python, Django
*   **AI Backend**: TensorFlow/Keras, Stable-Baselines3 (RL), Gymnasium
*   **Frontend**: Vanilla HTML5, CSS3, JavaScript (ES6+), Chart.js
*   **Integration**: Ngrok Secure Tunneling

## 7. Dataset & Data Management
The project relies on a multi-dimensional dataset located in the `data/` directory. These files provide the foundation for training and real-time decision-making:

*   **`uk_carbon_raw.csv`**: Contains historical and real-time carbon intensity (gCO2/kWh) for the UK National Grid. This is the primary feed for the LSTM model.
*   **`uk_carbon_forecast.csv`**: Pre-calculated carbon forecasts used for validation and as a secondary predictive source.
*   **`cloud_region_dataset.csv`**: A specialized dataset containing simulated carbon intensities for diverse cloud regions (UK, EU, US). This enables the RL agent to learn regional carbon-shifting patterns.
*   **Live Updates**: As the system runs, it automatically appends new "real-world" data points to the raw CSV to simulate a continuous grid feed.

## 8. How to Run the System
1.  **Start the Brain**: Run the `colab_api_bridge.py` script in Google Colab.
2.  **Connect**: Copy the Ngrok URL into `settings.py` -> `COLAB_API_URL`.
3.  **Launch Dashboard**: Run `python manage.py runserver` and open `http://127.0.0.1:8000`.

---
**Prepared by**: Sachal
**Topic**: Predictive Carbon-Aware RL Scheduler for Sustainable Cloud Computing
**Status**: Production-Ready / Thesis Deployment Finalized
