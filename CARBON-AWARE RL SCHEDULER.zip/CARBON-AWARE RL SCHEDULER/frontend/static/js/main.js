document.addEventListener('DOMContentLoaded', () => {
    const intensityEl = document.getElementById('current-intensity');
    const trendEl = document.getElementById('intensity-trend');
    const decisionEl = document.getElementById('decision-result');
    const reasonEl = document.getElementById('decision-reason');
    const scheduleBtn = document.getElementById('schedule-now-btn');
    const activityLog = document.getElementById('activity-log');
    const timerEl = document.getElementById('session-time');
    const apiStatusEl = document.getElementById('api-status');
    const jobQueue = document.getElementById('job-queue');
    const carbonSavedEl = document.getElementById('carbon-saved');
    const jobsCountEl = document.getElementById('jobs-count');
    
    let forecastChart;
    let startTime = Date.now();
    let jobsProcessed = 0;
    let totalCarbonReduction = 0;

    // Session Timer
    setInterval(() => {
        const elapsed = Date.now() - startTime;
        const h = Math.floor(elapsed / 3600000).toString().padStart(2, '0');
        const m = Math.floor((elapsed % 3600000) / 60000).toString().padStart(2, '0');
        const s = Math.floor((elapsed % 60000) / 1000).toString().padStart(2, '0');
        timerEl.textContent = `${h}:${m}:${s}`;
    }, 1000);

    function addLogEntry(message, type = 'system') {
        const entry = document.createElement('div');
        entry.className = `log-entry ${type}`;
        const time = new Date().toLocaleTimeString();
        entry.textContent = `[${time}] ${message}`;
        activityLog.prepend(entry);
        if (activityLog.children.length > 30) activityLog.removeChild(activityLog.lastChild);
    }

    function updateJobQueue(action, jobId) {
        if (action === 'DELAY') {
            if (jobQueue.querySelector('.queue-empty')) jobQueue.innerHTML = '';
            const item = document.createElement('div');
            item.className = 'queue-item-dynamic';
            item.innerHTML = `<span>JOB-${jobId}</span> <span class="tag-waiting">WAITING</span>`;
            item.id = `q-job-${jobId}`;
            jobQueue.appendChild(item);
        } else {
            const existing = document.getElementById(`q-job-${jobId}`);
            if (existing) {
                existing.classList.add('fade-out');
                setTimeout(() => {
                    existing.remove();
                    if (jobQueue.children.length === 0) {
                        jobQueue.innerHTML = '<div class="queue-empty">Queue is empty</div>';
                    }
                }, 500);
            }
        }
    }

    async function updateDashboard(isManual = false) {
        try {
            const jobId = Math.floor(Math.random() * 9000) + 1000;
            if (isManual) addLogEntry(`Submitting JOB-${jobId} to RL Agent...`, 'system');
            
            const response = await fetch('/api/schedule/');
            if (!response.ok) throw new Error('API Down');
            const data = await response.json();

            // API Status Check
            apiStatusEl.classList.add('online');
            
            // Update Intensity
            intensityEl.textContent = Math.round(data.carbon_estimate);
            
            // Update Trend & Metrics
            if (data.carbon_estimate < 160) {
                trendEl.textContent = '↓ LOW CARBON WINDOW';
                trendEl.style.color = '#10b981';
                totalCarbonReduction += 12.5; // Simulated accumulation
            } else {
                trendEl.textContent = '↑ HIGH CARBON PEAK';
                trendEl.style.color = '#ef4444';
            }

            // Update Decision
            decisionEl.textContent = data.action;
            decisionEl.className = `decision-pill ${data.action.toLowerCase().includes('delay') ? 'delay' : 'run'}`;
            reasonEl.textContent = data.reason;

            if (isManual) {
                jobsProcessed++;
                jobsCountEl.textContent = jobsProcessed;
                carbonSavedEl.textContent = (totalCarbonReduction / jobsProcessed).toFixed(1) + '%';
                updateJobQueue(data.action.includes('DELAY') ? 'DELAY' : 'RUN', jobId);
            }

            addLogEntry(`RL RESPONSE for JOB-${jobId}: ${data.action}`, 'decision');

            // Fetch forecast for chart
            const forecastRes = await fetch('/api/forecast/');
            const forecastData = await forecastRes.json();
            renderChart(forecastData.forecasts);

        } catch (error) {
            console.error('Error fetching dashboard data:', error);
            apiStatusEl.classList.remove('online');
            addLogEntry('CRITICAL: Colab API Connection Interrupted!', 'warning');
        }
    }

    function renderChart(forecasts) {
        const ctx = document.getElementById('forecastChart').getContext('2d');
        const labels = forecasts.map(f => f.timestamp + ':00');
        const values = forecasts.map(f => f.forecast_carbon_intensity);

        if (forecastChart) forecastChart.destroy();

        const gradient = ctx.createLinearGradient(0, 0, 0, 400);
        gradient.addColorStop(0, 'rgba(16, 185, 129, 0.4)');
        gradient.addColorStop(1, 'rgba(16, 185, 129, 0)');

        forecastChart = new Chart(ctx, {
            type: 'line',
            data: {
                labels: labels,
                datasets: [{
                    label: 'gCO2/kWh Projection',
                    data: values,
                    borderColor: '#10b981',
                    backgroundColor: gradient,
                    fill: true,
                    tension: 0.4,
                    pointRadius: 4,
                    borderWidth: 3
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                scales: {
                    y: { grid: { color: 'rgba(148, 163, 184, 0.1)' }, ticks: { color: '#94a3b8' } },
                    x: { grid: { display: false }, ticks: { color: '#94a3b8' } }
                },
                plugins: { legend: { display: false } }
            }
        });
    }

    scheduleBtn.addEventListener('click', () => {
        scheduleBtn.textContent = 'SCHEDULING...';
        scheduleBtn.disabled = true;
        setTimeout(() => {
            updateDashboard(true);
            scheduleBtn.textContent = 'SUBMIT JOB';
            scheduleBtn.disabled = false;
        }, 1000);
    });

    // Initial load
    addLogEntry('Establishing handshake with ' + window.location.host, 'system');
    updateDashboard();
    setInterval(updateDashboard, 120000);
});
